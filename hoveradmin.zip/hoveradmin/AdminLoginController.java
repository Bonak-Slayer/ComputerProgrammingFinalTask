/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hoveradmin;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Lord Geese
 */
public class AdminLoginController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @FXML Label userNameError, passError;
    @FXML TextField usernameField;
    @FXML PasswordField passField;
    
    @FXML
    public void accessComplete(ActionEvent event) throws Exception{
        if(usernameField.getText().isEmpty() && passField.getText().isEmpty()){
            userNameError.setText("*This field cannot be empty.");
            passError.setText("*This field cannot be empty.");
        }
        else if(usernameField.getText().equals("Admin") && passField.getText().equals("lordgeese")){
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("PlayVideoScreen.fxml"));
            Parent root = loader.load();
            
            Scene videoScene = new Scene(root);
            Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
            window.close();
            
            Stage next = new Stage();
            next.setScene(videoScene);
            next.setTitle("Welcome, Admin");
            next.centerOnScreen();
            next.show();
        }
        else if(usernameField.getText().equals("Admin") && !passField.getText().equals("lordgeese")){
            userNameError.setText("");
            passError.setText("*Incorrect password");
        }
        else if(!usernameField.getText().equals("Admin")){
            userNameError.setText("*Invalid username");
            passError.setText("");
        }
    }
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
