/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hoveradmin;

import java.sql.*;

/**
 *
 * @author Lord Geese
 */
public class DatabaseManipulation {
    private String username = "flightMaster";
    private String password = "accessFlights";
    private String url = "jdbc:mysql://localhost:3306/allFlights";
    private String query = "";
    private Connection conn;
    
    public void changePassDB(String user, String newPass){
        try{
            conn = DriverManager.getConnection(url, username, password);
            query = "UPDATE user_information SET password = ? WHERE username = ?";
            System.out.println("Checking database!");
            
            PreparedStatement prep = conn.prepareStatement(query);
            prep.setString(1, newPass);
            prep.setString(2, user);
            prep.execute();
            System.out.println("Password successfully changed!");
            
        }catch(Exception e){
            System.out.println(e);
        }finally{
            try{
                conn.close();
            }catch(Exception e1){
                System.out.println(e1);
            }
        }
    }//Method End
    
    public void removeUserFromFlight(String user){
        try{
            conn = DriverManager.getConnection(url, username, password);
            query = "DELETE FROM bookedFlights WHERE true_name = ?";
            System.out.println("Checking database!");
            
            PreparedStatement prep = conn.prepareStatement(query);
            prep.setString(1, user);
            prep.execute();
            
            System.out.println("User successfully removed!");
            
            query = "UPDATE user_information SET has_reservation = 0 WHERE real_name = ?";
            prep = conn.prepareStatement(query);
            prep.setString(1, user);
            prep.execute();
            
            System.out.println("User info updated!");
            
        }catch(Exception e){
            System.out.println(e);
        }finally{
            try{
                conn.close();
            }catch(Exception e1){
                System.out.println(e1);
            }
        }
    }
    
}
