/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hoveradmin;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.media.MediaView;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Lord Geese
 */
public class PlayVideoScreenController implements Initializable {
    @FXML private Media media;
    @FXML private MediaPlayer play;
    @FXML private MediaView video;
    
    private void checkStatus() throws Exception{
        play.setAutoPlay(true);
        
        play.setOnEndOfMedia(new Runnable(){
            @Override
            public void run() {
                try {
                    tableScreen();             
                } 
                catch(Exception e){
                    System.out.println(e);
                }
            }          
        });
    }
    
    private void tableScreen() throws Exception{ 
        Scene welcomeScreenScene = video.getScene();
        Stage welcomeEnd = (Stage)welcomeScreenScene.getWindow();
        welcomeEnd.close();
        
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("Tables.fxml"));
        Parent mainScreen = loader.load();
        
        Scene mainScreenScene = new Scene(mainScreen);
        Stage mainScreenStart = new Stage();
        mainScreenStart.setMaxWidth(1620);
        mainScreenStart.setMaxHeight(1050);
        mainScreenStart.setScene(mainScreenScene);
        mainScreenStart.centerOnScreen();
        mainScreenStart.setTitle("Administrator");
        mainScreenStart.showAndWait();     
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb){
       String videoSource = "file:/C:/Users/administrator.mp4";
       media = new Media(videoSource);
       play = new MediaPlayer(media);  
       video.setMediaPlayer(play);
       
       try {
            checkStatus();
       }
       catch(Exception error) {
            System.out.println(error);
       }     
    }    
}
