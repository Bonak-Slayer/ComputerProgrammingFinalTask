/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hoveradmin;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Lord Geese
 */
public class TablesController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @FXML TableView<DatabaseManager> table, FlightTable;
    
    //COLUMNS FOR USERS TABLE
    @FXML TableColumn<DatabaseManager, Integer> userIDColumn, reserColumn;
    @FXML TableColumn<DatabaseManager, String> usernameColumn, passColumn, realNameColumn, mailColumn, contactColumn;
    
    //COLUMNS FOR FLIGHTS TABLE
    @FXML TableColumn<DatabaseManager, Integer> flightUserColumn;
    @FXML TableColumn<DatabaseManager, String>fNameColumn, fRNameColumn, fDurationColumn, fTimeColumn, 
            fDateColumn, fPriceColumn;
    
    //TABLE MORPH BUTTONS
    @FXML Button FlightButton, UserInfoButton;
    
    //DB MANIPULATION BUTTONS
    @FXML Button ChangePass, RemoveButton;
    
    //SHOW SPECIFIC FLIGHTS
    @FXML Button PhiJpn, PhiTha, PhiIdn, JpnPhi, JpnKor, IdnKor, IdnPhi, KorIdn, KorJpn, ThaPhi;
    
    //SEARCH ELEMENTS
    @FXML TextField SearchBox;
    @FXML Button SearchButton;
    
    //LOG OUT
    @FXML Button LogOutButton;
    
    //BUTTON FUNCTIONS
    public void showUsers(){
        table.setVisible(true);
        FlightTable.setVisible(false);
        
        //Prepare to set cell values
        userIDColumn.setCellValueFactory(new PropertyValueFactory<DatabaseManager, Integer>("user_id"));
        usernameColumn.setCellValueFactory(new PropertyValueFactory<DatabaseManager, String>("user"));
        passColumn.setCellValueFactory(new PropertyValueFactory<DatabaseManager, String>("pass"));
        realNameColumn.setCellValueFactory(new PropertyValueFactory<DatabaseManager, String>("realName"));
        mailColumn.setCellValueFactory(new PropertyValueFactory<DatabaseManager, String>("email"));
        contactColumn.setCellValueFactory(new PropertyValueFactory<DatabaseManager, String>("contactNumber"));
        reserColumn.setCellValueFactory(new PropertyValueFactory<DatabaseManager, Integer>("has_reservation"));
        
        table.setItems(getUserValues());
    }
    
    public void showFlights(){
        FlightTable.setVisible(true);
        table.setVisible(false);

        //Prepare to set cell values
        PrepareCells();
        
        FlightTable.setItems(getFlightValues());
    }
    
    //SHOW SPECIFIC VALUES
    public void showSpecificFlights(ActionEvent event) throws Exception{
        table.setVisible(false);
        FlightTable.setVisible(true);
        
        //WHEN THE SEARCH BUTTON IS PRESSED, DO THIS
        if(event.getSource() == SearchButton){
            PrepareCells();
            FlightTable.setItems(getSpecific("Search", SearchBox.getText()));
        }
        //THESE ARE FLIGHT BUTTONS
        else if(event.getSource() == PhiJpn){
            PrepareCells();
            FlightTable.setItems(getSpecific(PhiJpn.getText(), ""));
        }
        else if(event.getSource() == PhiTha){
            PrepareCells();
            FlightTable.setItems(getSpecific(PhiTha.getText(), ""));
        }
        else if(event.getSource() == PhiIdn){
            PrepareCells();
            FlightTable.setItems(getSpecific(PhiIdn.getText(), ""));
        }
        else if(event.getSource() == JpnPhi){
            PrepareCells();
            FlightTable.setItems(getSpecific(JpnPhi.getText(), ""));
        }
        else if(event.getSource() == JpnKor){
            PrepareCells();
            FlightTable.setItems(getSpecific(JpnKor.getText(), ""));
        }
        else if(event.getSource() == IdnKor){
            PrepareCells();
            FlightTable.setItems(getSpecific(IdnKor.getText(), ""));
        }
        else if(event.getSource() == IdnPhi){
            PrepareCells();
            FlightTable.setItems(getSpecific(IdnPhi.getText(), ""));
        }
        else if(event.getSource() == KorIdn){
            PrepareCells();
            FlightTable.setItems(getSpecific(KorIdn.getText(), ""));
        }
        else if(event.getSource() == KorJpn){
            PrepareCells();
            FlightTable.setItems(getSpecific(KorJpn.getText(), ""));
        }
        else if(event.getSource() == ThaPhi){
            PrepareCells();
            FlightTable.setItems(getSpecific(ThaPhi.getText(), ""));
        }
        
    }
    
    //OBSERVABLE LISTS TO BE USED IN COLUMNS
    public ObservableList<DatabaseManager> getUserValues(){
        ObservableList<DatabaseManager> userList;
        DatabaseManager adminUser = new DatabaseManager();
        
        userList = adminUser.getUserInfo();
        return userList;
    }
    
    public ObservableList<DatabaseManager> getFlightValues(){
        ObservableList<DatabaseManager> flightList;
        DatabaseManager adminUser = new DatabaseManager();
        
        flightList = adminUser.getFlightInfo();
        return flightList;
    }
    
    public ObservableList<DatabaseManager> getSpecific(String specific, String user){
        ObservableList<DatabaseManager> flightList;
        DatabaseManager adminUser = new DatabaseManager();
        
        flightList = adminUser.getSpecificFlightInfo(specific, user);
        
        return flightList;
    }
    
    //Prepare cells
    public void PrepareCells(){
        flightUserColumn.setCellValueFactory(new PropertyValueFactory<DatabaseManager, Integer>("flightID"));
        fRNameColumn.setCellValueFactory(new PropertyValueFactory<DatabaseManager, String>("flightRealName"));
        fNameColumn.setCellValueFactory(new PropertyValueFactory<DatabaseManager, String>("flightName"));
        fDurationColumn.setCellValueFactory(new PropertyValueFactory<DatabaseManager, String>("flightDuration"));
        fTimeColumn.setCellValueFactory(new PropertyValueFactory<DatabaseManager, String>("flightTime"));
        fDateColumn.setCellValueFactory(new PropertyValueFactory<DatabaseManager, String>("flightDate"));
        fPriceColumn.setCellValueFactory(new PropertyValueFactory<DatabaseManager, String>("flightPrice"));
    }
    //CHANGE PASSWORD
    @FXML
    public void changePassword(ActionEvent event) throws Exception{
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("PasswordChangeScreen.fxml"));
        Parent root = loader.load();
            
        Scene changeScene = new Scene(root);
            
        Stage next = new Stage();
        next.setScene(changeScene);
        next.setTitle("Change Password");
        next.centerOnScreen();
        next.setMaxWidth(650);
        next.setMaxHeight(440);
        next.show();
    }
    
    //DELETE USER FROM FLIGHT
    @FXML
    public void removeFromFlight(ActionEvent event) throws Exception{
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("RemoveUserFlight.fxml"));
        Parent root = loader.load();
            
        Scene changeScene = new Scene(root);
            
        Stage next = new Stage();
        next.setScene(changeScene);
        next.setTitle("Remove a User");
        next.centerOnScreen();
        next.setMaxWidth(650);
        next.setMaxHeight(440);
        next.show();
    }
    
    
    //RETURN TO LOGIN SCREEN
    @FXML
    public void returnToLogin(ActionEvent event) throws Exception{
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("SignOut.fxml"));
        Parent root = loader.load();
            
        Scene videoScene = new Scene(root);
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.close();
            
        Stage next = new Stage();
        next.setScene(videoScene);
        next.setTitle("Farewell, Admin");
        next.centerOnScreen();
        next.show();
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        showUsers();
    }    
    
}
