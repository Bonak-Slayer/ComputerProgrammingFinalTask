/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hoveradmin;

import java.sql.*;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author Lord Geese
 */
public class DatabaseManager {
    //Values for user info
    private SimpleIntegerProperty user_id, has_reservation;
    private SimpleStringProperty user, pass, realName, email, contactNumber;
    
    //Values for flights
    private SimpleIntegerProperty flightID;
    private SimpleStringProperty flightRealName, flightName, flightDuration, flightTime, flightDate, flightPrice;
    
    //Values for database access
    private String username = "flightMaster";
    private String password = "accessFlights";
    private String url = "jdbc:mysql://localhost:3306/allFlights";
    private String query;
    private Connection conn;
    
    //Observable Lists
    private ObservableList<DatabaseManager> userInformation, flightInformation;
    
    //CONSTRUCTORS
    public DatabaseManager(){
        
    }
    
    //CONSTRUCTOR FOR USER INFORMATION
    public DatabaseManager(int uid, String user, String pass, String real, String mail, String contact, int reserve){
        this.user_id = new SimpleIntegerProperty(uid);
        this.user = new SimpleStringProperty(user);
        this.pass = new SimpleStringProperty(pass);
        this.realName = new SimpleStringProperty(real);
        this.email = new SimpleStringProperty(mail);
        this.contactNumber = new SimpleStringProperty(contact);
        this.has_reservation = new SimpleIntegerProperty(reserve);
    }
    
    //CONSTRUCTOR FOR FLIGHT INFORMATION
    public DatabaseManager(int uid, String real, String fName, String fDuration, String fTime, String fDate, String fPrice){
        this.flightID = new SimpleIntegerProperty(uid);
        this.flightRealName = new SimpleStringProperty(real);
        this.flightName = new SimpleStringProperty(fName);
        this.flightDuration = new SimpleStringProperty(fDuration);    
        this.flightTime = new SimpleStringProperty(fTime);
        this.flightDate = new SimpleStringProperty(fDate);
        this.flightPrice = new SimpleStringProperty(fPrice);
    }
    
    //METHODS FOR ACCESSING DATABASE
    public ObservableList<DatabaseManager> getUserInfo(){
        try{
            conn = DriverManager.getConnection(url, username, password);
            System.out.println("Connection success!");
            
            userInformation = FXCollections.observableArrayList();
            query = "SELECT * FROM user_information";
            
            
            PreparedStatement prep = conn.prepareStatement(query);
            ResultSet rs = prep.executeQuery();
            
            while(rs.next()){
                userInformation.add(new DatabaseManager(rs.getInt("user_id"), rs.getString("username"), 
                rs.getString("password"), rs.getString("real_name"), rs.getString("email"), 
                rs.getString("contact_number"), rs.getInt("has_reservation")));
            }
            
            
        }catch(Exception e){
            System.out.println(e);
        }finally{
            try{
                conn.close();
            }catch(Exception e1){
                System.out.println(e1);
            }
        }
        return userInformation;
    }//Method End
    
    public ObservableList<DatabaseManager> getFlightInfo(){
        try{
            conn = DriverManager.getConnection(url, username, password);
            flightInformation = FXCollections.observableArrayList();
            System.out.println("Flight information table accessed!");
            
            query = "SELECT * FROM bookedFlights";
            PreparedStatement prep = conn.prepareStatement(query);
            ResultSet rs = prep.executeQuery();
            
            while(rs.next()){
                flightInformation.add(new DatabaseManager(rs.getInt("id"), rs.getString("true_name"), 
                rs.getString("flight_name"), rs.getString("flight_duration"), rs.getString("time_of_flight"), 
                rs.getString("flight_date"), rs.getString("amount")));
            }
            System.out.println("Items successfully stored!");
            
        }catch(Exception e){
            System.out.println(e);
        }finally{
            try{
                conn.close();
            }catch(Exception e1){
                System.out.println(e1);
            }
        }//Finally End
        return flightInformation;
    }//Method End
    
    public ObservableList<DatabaseManager> getSpecificFlightInfo(String specific, String user){
        try{
            conn = DriverManager.getConnection(url, username, password);
            flightInformation = FXCollections.observableArrayList();
            System.out.println("Flight information table accessed!");
            
            //If the search button is pressed, use this
            if(specific.equals("Search")){
                query = "SELECT * FROM bookedFlights WHERE true_name = ?";
                PreparedStatement prep = conn.prepareStatement(query);
                prep.setString(1, user);
                ResultSet rs = prep.executeQuery();

                while(rs.next()){
                    flightInformation.add(new DatabaseManager(rs.getInt("id"), rs.getString("true_name"), 
                    rs.getString("flight_name"), rs.getString("flight_duration"), rs.getString("time_of_flight"), 
                    rs.getString("flight_date"), rs.getString("amount")));
                }
                System.out.println("Items successfully stored!");
            }
            else{
                query = "SELECT * FROM bookedFlights WHERE flight_name = ?";
                PreparedStatement prep = conn.prepareStatement(query);
                prep.setString(1, specific);
                ResultSet rs = prep.executeQuery();

                while(rs.next()){
                    flightInformation.add(new DatabaseManager(rs.getInt("id"), rs.getString("true_name"), 
                    rs.getString("flight_name"), rs.getString("flight_duration"), rs.getString("time_of_flight"), 
                    rs.getString("flight_date"), rs.getString("amount")));
                }
                System.out.println("Items successfully stored!");
            }
            
        }catch(Exception e){
            System.out.println(e);
        }finally{
            try{
                conn.close();
            }catch(Exception e1){
                System.out.println(e1);
            }
        }//Finally End
        return flightInformation;
    }//Method End
    
    
    //GETTER AND SETTER METHODS FOR USER INFO
    public int getUser_id() {
        return user_id.get();
    }

    public void setUser_id(SimpleIntegerProperty user_id) {
        this.user_id = user_id;
    }

    public String getContactNumber() {
        return contactNumber.get();
    }

    public void setContactNumber(SimpleStringProperty contactNumber) {
        this.contactNumber = contactNumber;
    }

    public int getHas_reservation() {
        return has_reservation.get();
    }

    public void setHas_reservation(SimpleIntegerProperty has_reservation) {
        this.has_reservation = has_reservation;
    }

    public String getUser() {
        return user.get();
    }

    public void setUser(SimpleStringProperty user) {
        this.user = user;
    }

    public String getPass() {
        return pass.get();
    }

    public void setPass(SimpleStringProperty pass) {
        this.pass = pass;
    }

    public String getRealName() {
        return realName.get();
    }

    public void setRealName(SimpleStringProperty realName) {
        this.realName = realName;
    }

    public String getEmail() {
        return email.get();
    }

    public void setEmail(SimpleStringProperty email) {
        this.email = email;
    }
    
    //GETTER AND SETTER METHODS FOR FLIGHT INFO

    public int getFlightID() {
        return flightID.get();
    }

    public void setFlightID(SimpleIntegerProperty flightID) {
        this.flightID = flightID;
    }

    public String getFlightRealName() {
        return flightRealName.get();
    }

    public void setFlightRealName(SimpleStringProperty flightRealName) {
        this.flightRealName = flightRealName;
    }
 

    public String getFlightName() {
        return flightName.get();
    }

    public void setFlightName(SimpleStringProperty flightName) {
        this.flightName = flightName;
    }

    public String getFlightDuration() {
        return flightDuration.get();
    }

    public void setFlightDuration(SimpleStringProperty flightDuration) {
        this.flightDuration = flightDuration;
    }

    public String getFlightTime() {
        return flightTime.get();
    }

    public void setFlightTime(SimpleStringProperty flightTime) {
        this.flightTime = flightTime;
    }

    public String getFlightDate() {
        return flightDate.get();
    }

    public void setFlightDate(SimpleStringProperty flightDate) {
        this.flightDate = flightDate;
    }

    public String getFlightPrice() {
        return flightPrice.get();
    }

    public void setFlightPrice(SimpleStringProperty flightPrice) {
        this.flightPrice = flightPrice;
    }
    
}
