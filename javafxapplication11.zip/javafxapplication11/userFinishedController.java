/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafxapplication11;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.media.MediaView;
import javafx.stage.Stage;
/**
 * FXML Controller class
 *
 * @author Lord Geese
 */
public class userFinishedController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @FXML
    private Media media;
    @FXML
    private MediaPlayer play;
    @FXML
    private MediaView signOutViewer;
    
    @FXML
    private void checkStatus() throws Exception{
        play.setAutoPlay(true);
        
        play.setOnEndOfMedia(new Runnable(){
            @Override
            public void run() {
                try {
                    loginScreen();             
                } 
                catch(Exception e){
                    System.out.println(e);
                }
            }          
        });
    }
    
    @FXML
    private void loginScreen() throws Exception{ 
        Scene signOutScene = signOutViewer.getScene();
        Stage signOutEnd = (Stage)signOutScene.getWindow();
        signOutEnd.close();
        
        Parent loginScreen = FXMLLoader.load(getClass().getResource("Login.fxml"));
        Scene loginScreenScene = new Scene(loginScreen);
        Stage loginScreenStart = new Stage();
        loginScreenStart.setScene(loginScreenScene);
        loginScreenStart.setTitle("Log In");
        loginScreenStart.centerOnScreen();
        loginScreenStart.show();
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        String videoSource = "file:/C:/Users/signOut.mp4";
        media = new Media(videoSource);
        play = new MediaPlayer(media);  
        signOutViewer.setMediaPlayer(play);
       
       try {
            checkStatus();
       }
       catch(Exception error) {
            System.out.println(error);
       }
    }    
    
}
