/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafxapplication11;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Lord Geese
 */
public class UpdateBookingController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @FXML Label confirmMessage, FlightName, TimeValue, DateValue, DurationValue;
    @FXML Button promptButton;
    
    private String name;
    private UpdateDatabase update;

    //Necessary passing of information so that the username is not lost
    //This is crucial information when accessing the database
    public void saveUserName(String name){
        this.name = name;
    }
    
    //This changes the text on controllers depending on what button the user pressed
    //The text is different for the flight cancellation and flight rescheduling
    @FXML
    public void changeTexts(String confirm, String flightName, String flightDuration, String flightDate, 
            String flightTime, String prompt){
        confirmMessage.setText(confirm);
        FlightName.setText(flightName);
        TimeValue.setText(flightTime);
        DateValue.setText(flightDate);
        DurationValue.setText(flightDuration);
        promptButton.setText(prompt);
    }
    
    @FXML
    private void MainScreen(ActionEvent event) throws Exception{
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("MainScreen.fxml"));
        Parent main = loader.load();
        
        MainScreenController control = loader.getController();
        control.saveUserName(name);
        
        Scene mainScene = new Scene(main);
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(mainScene);
        window.setTitle("Hover");
        window.show();
    }
    
    @FXML
    private void nextAction(ActionEvent event) throws Exception{
        update = new UpdateDatabase(name);
        
        //This check is necessary so that it will essentially be a single button with two functions
        //It can either be used to load the cancel booking screen or the reschedule screen
        if(promptButton.getText().equals("Yes, I want to cancel this booking.")){
            
            //This method removes the booking from the bookedFlights database
            //Futhermore, it sets the reservation boolean to false in the user information DB
            update.removeFromDatabase();
            
            //After those are done, the flight cancel screen will now be loaded
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("FlightCancelSuccess.fxml"));
            Parent cancel = loader.load();

            FlightCancelSuccessController control = loader.getController();
            control.saveUserName(name);

            Scene cancelScene = new Scene(cancel);
            Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
            window.setScene(cancelScene);
            window.centerOnScreen();
            window.setTitle("Flight Cancelled");
            window.show();
        }
        else{
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("BookingConfirmation.fxml"));
            Parent book = loader.load();

            BookingConfirmationController control = loader.getController();
            control.changeFlightLabel(FlightName.getText());
            control.changeValues(FlightName.getText());
            control.saveUserName(name);

            Scene mainScene = new Scene(book);
            Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
            window.setScene(mainScene);
            window.setTitle("Reschedule");
            window.show();
        }
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
