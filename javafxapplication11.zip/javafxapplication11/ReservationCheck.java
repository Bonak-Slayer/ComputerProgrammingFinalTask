/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafxapplication11;

import java.sql.*;
/**
 *
 * @author Lord Geese
 */
public class ReservationCheck {
    private String url = "jdbc:mysql://localhost:3306/allFlights";
    private String username = "flightMaster";
    private String password = "accessFlights";
    private Connection conn;
    
    private String query = "";
    private String name, realName;
    private String flightInfo;
    private String fName, fDuration, fDate, fTime;
    private String confirmationMessage, buttonPrompt, bookedFlight;
    private boolean hasReservation;
    private int confirm;
    
    public ReservationCheck(String name){
        this.name = name;
    }
    
    //This method will check the DB if the user already has a reservation
    //If yes, it will return true
    public boolean checkForReservations(){
        try{
            conn = DriverManager.getConnection(url, username, password);
            
            query = "SELECT has_reservation FROM user_information WHERE username = ?";
            
            PreparedStatement prep = conn.prepareStatement(query);
            prep.setString(1, name);
            ResultSet rs = prep.executeQuery();
            
            while(rs.next()){
                confirm = rs.getInt(1);
            }
            
            if(confirm == 1){
                hasReservation = true;
            }
            
        }catch(SQLException e){
            System.out.println(e);
        }finally{
            try{
                if(conn != null){
                    conn.close();
                }
            }catch(Exception h){
                System.out.println(h);
            }
        }
        //Return a value which is basically true or false
        return hasReservation;
    }//Method end
    
    //Accesses the database to get the flights
    public String getFlight(String category){
        try{
            conn = DriverManager.getConnection(url, username, password);
            
            //This is to get the real name of the user first, which is not present in the other DB
            query = "SELECT real_name FROM user_information WHERE username = ?";
            System.out.println("Accessing first database...");
            
            PreparedStatement prep = conn.prepareStatement(query);
            prep.setString(1, name);
            ResultSet rs = prep.executeQuery();
            
            while(rs.next()){
                realName = rs.getString(1);
            }
            System.out.println("Retrieval successful!");
            
            //After doing the first query, now we will get the booked flight using the real name of the user
            query = "SELECT flight_name, flight_duration, flight_date, time_of_flight FROM bookedFlights WHERE true_name = ?";
            System.out.println("Now accessing second database...");
            
            prep = conn.prepareStatement(query);
            prep.setString(1, realName);
            rs = prep.executeQuery();
            
            while(rs.next()){
                fName = rs.getString(1);
                fDuration = rs.getString(2);
                fDate = rs.getString(3);
                fTime = rs.getString(4);
            }
            
            switch(category){
                case "name":
                    flightInfo = fName;
                    break;
                case "duration":
                    flightInfo = fDuration;
                    break;
                case "date":
                    flightInfo = fDate;
                    break;
                case "time":
                    flightInfo = fTime;
                    break;
            }
            
            System.out.println("Retrieval Complete!");
        }catch(SQLException e){
            System.out.println(e);
        }finally{
            try{
                
            }catch(Exception b){
                System.out.println(b);
            }
        }
        return flightInfo;
    }//Method end
    
}
