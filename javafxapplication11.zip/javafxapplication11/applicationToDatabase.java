/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafxapplication11;

import java.sql.*;
/**
 *
 * @author Lord Geese
 */
public class applicationToDatabase {
    private String query;
    private String url = "jdbc:mysql://localhost:3306/allFlights";
    private String username = "flightMaster";
    private String password = "accessFlights";
    private Connection conn;
    
    private String userName, passWord, realName, contactNumber, email;
    private String flight, flightTime, flightDate;
    
    private String signInIssue;
    private String retrievedName, retrievedPass;
    private String desiredUsername, similarRealName;
    private String usernameCheck, realNameCheck;
    
    //Constructor to be used for account creation
    public applicationToDatabase(String userName, String passWord, String realName, String contactNumber, String email){
        this.userName = userName;
        this.passWord = passWord;
        this.realName = realName;
        this.contactNumber = contactNumber;
        this.email = email;
    }
    
    //Constructor to be used for login
    public applicationToDatabase(String userName, String passWord){
        this.userName = userName;
        this.passWord = passWord;    
    }
    
    public applicationToDatabase(){
        
    }
    
    public void createAccount(){
        try{   
            conn = DriverManager.getConnection(url, username, password);
            System.out.println("Successfully created an account!");
            
            query = "INSERT INTO user_information(username, password, real_name, email, contact_number, has_reservation) " +
                    "VALUES(?,?,?,?,?,?)";
            
            PreparedStatement prep = conn.prepareStatement(query);
            prep.setString(1, userName);
            prep.setString(2, passWord);
            prep.setString(3, realName);
            prep.setString(4, email);
            prep.setString(5, contactNumber);
            prep.setInt(6, 0);
            prep.execute();            
            
        }catch(SQLException e){
            System.out.println(e.getMessage());
        }
        //closing the connection
        finally{
            try{
                if(conn != null){
                    conn.close();
                }
            }catch(SQLException e1){
                System.out.println(e1.getMessage());
            }//catch end
        }//finally end
    }//account creation end
    
    public String signIn(){
        try{        
            conn = DriverManager.getConnection(url, username, password);
            System.out.println("Currently checking database!");
            
            query = "SELECT username, password FROM user_information WHERE username = ?";
            
            PreparedStatement state = conn.prepareStatement(query);
            state.setString(1, userName);
            ResultSet rs = state.executeQuery();
            
            while(rs.next()){
                retrievedName = rs.getString(1);
                retrievedPass = rs.getString(2);
            }           
            
            //Will return a string depending on what values the database has returned
            //This returned string will then be used in a switch in the login controller
            if(userName.equals(retrievedName) && passWord.equals(retrievedPass)){
                signInIssue = "Success";
            }
            else if(!userName.equals(retrievedName)){
                signInIssue = "NoUser";
            }
            else if(userName.equals(retrievedName) && !passWord.equals(retrievedPass)){
                signInIssue = "IncorrectPass";
            }
            else{
                signInIssue = "Both";
            }
            
            state.close();
            rs.close();
            
        }catch(SQLException e){
            System.out.println(e);
        }
        finally{
           try{
               if(conn != null){
                   conn.close();
               }
           }catch(SQLException e1){
                System.out.println(e1.getMessage());
            }
        }//Closing the connection
        return signInIssue;
    }//Sign in method end
    
    public String checkForSimilarUsername(String enteredUsername){
        try{
            conn = DriverManager.getConnection(url, username, password);
            System.out.println("Checking for similar usernames!");
            
            //Check if there's already a similar username in the database
            query = "SELECT username FROM user_information WHERE username = ?";
            PreparedStatement prep = conn.prepareStatement(query);
            
            prep.setString(1, enteredUsername);
            ResultSet rs = prep.executeQuery();
            
            while(rs.next()){
                desiredUsername = rs.getString(1);
            }
            
            System.out.println("Similar username check successful!");
        }
        catch(Exception e){
            System.out.println(e);
        }finally{
            try{
                conn.close();
            }
            catch(Exception r){
                System.out.println(r);
            }
        }
        return desiredUsername;
    }
    
    public String checkForSimilarRealName(String enteredRealName){
        try{
            conn = DriverManager.getConnection(url, username, password);
            System.out.println("Checking for a user with a similar real name...");
            
            //Check if there's already a user with the same real name in the database
            query = "SELECT real_name FROM user_information WHERE real_name = ?";
            PreparedStatement prep = conn.prepareStatement(query);
            prep.setString(1, enteredRealName);
            
            ResultSet rs = prep.executeQuery();
            while(rs.next()){
                similarRealName = rs.getString(1);
            }
            
            System.out.println("Real name check successful!");
        }catch(Exception e){
            System.out.println(e);
        }finally{
            try{
                conn.close();
            }
            catch(Exception r){
                System.out.println(r);
            }
        }
        return similarRealName;
    }
}
