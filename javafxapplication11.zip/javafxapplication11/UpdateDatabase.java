/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafxapplication11;

import java.sql.*;
/**
 *
 * @author Lord Geese
 */
public class UpdateDatabase {
    private String url = "jdbc:mysql://localhost:3306/allFlights";
    private String username = "flightMaster";
    private String password = "accessFlights";
    private Connection conn;
    
    private String query;
    private String name, realName;
    
    public UpdateDatabase(String name){
        this.name = name;
    }
    
    //This is used for cancellation of flights
    public void removeFromDatabase(){
        try{
            conn = DriverManager.getConnection(url, username, password);
            System.out.println("Accessing the first database... (deleting records)");
            
            //Storing the real name in a variable
            query = "SELECT real_name FROM user_information WHERE username = ?";
            
            PreparedStatement prep = conn.prepareStatement(query);
            prep.setString(1, name);
            ResultSet rs = prep.executeQuery();
            
            while(rs.next()){
                realName = rs.getString(1);
            }
            System.out.println("Storage complete!");
            
            //Changing the reservation status in the first database
            query = "UPDATE user_information SET has_reservation = ? WHERE username = ?";
            prep = conn.prepareStatement(query);
            prep.setInt(1, 0);
            prep.setString(2, name);
            prep.execute();
            System.out.println("Update complete!");
            
            //Removing the booking from the 2nd database
            query = "DELETE FROM bookedFlights WHERE true_name = ?";
            prep = conn.prepareStatement(query);
            prep.setString(1, realName);
            prep.execute();
            System.out.println("Deletion complete!");
            
        }catch(SQLException e){
            System.out.println(e);
        }finally{
            try{
                if(conn != null){
                    conn.close();
                }
            }catch(Exception b){
                System.out.println(b);
            }
        }
    }//Method end
}
