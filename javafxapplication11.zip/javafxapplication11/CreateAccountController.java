/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafxapplication11;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Lord Geese
 */
public class CreateAccountController implements Initializable {

    public TextField realName, userName;
    public PasswordField passWord, confirmPass;
    public TextField emailInput, contactNum;
    
    public Label realNameError;
    public Label uNameError;
    public Label passError;
    public Label matchError;
    public Label emailError;
    public Label numberError;

    private applicationToDatabase personInfo, similarValueCheck;

    @FXML
    private void returnToLogin(ActionEvent event) throws Exception{
        Parent returnToLogin = FXMLLoader.load(getClass().getResource("Login.fxml"));
        
        Scene returnToLoginScene = new Scene(returnToLogin);
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        
        window.setScene(returnToLoginScene);
        window.setTitle("Log In");
        window.show();
    }
    
    @FXML
    private void finishCreation(ActionEvent event) throws Exception{   
        checkValues();
        
        //If all the fields have been filled accordingly, return to the login screen
        if(checkValues() == true){
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("Login.fxml"));
            Parent login = loader.load();
            
            personInfo = new applicationToDatabase(userName.getText(), confirmPass.getText(), realName.getText(),
            contactNum.getText(), emailInput.getText());
            
            personInfo.createAccount();
                 
            Scene returnToLoginScene = new Scene(login);
            Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();

            window.setScene(returnToLoginScene);
            window.centerOnScreen();
            window.setTitle("Log In");
            window.show();
        }  
    }
    
    //This method would check the values inside each textfield
    //It would return different types of errors in the form of labels depending on the misinput of the user
    @FXML
    private boolean checkValues(){
        boolean creationSuccess = false;
        
        similarValueCheck = new applicationToDatabase();
        
        realNameError.setText("");
        uNameError.setText("");
        passError.setText("");
        matchError.setText("");
        emailError.setText("");
        numberError.setText("");
        
        String storeRealNameText = realName.getText();
        String storeUserNameText = userName.getText();
        String realNameCheck = similarValueCheck.checkForSimilarRealName(storeRealNameText);
        String userNameCheck = similarValueCheck.checkForSimilarUsername(storeUserNameText);
        
        //These arrays are necessary so that they are easier to access rather than coding them all using if-else
        String[] checkTextFields = {realName.getText(), userName.getText(), passWord.getText(), confirmPass.getText(),
        emailInput.getText(), contactNum.getText()};
        
        boolean[] checkFieldsFilledCorrectly = {false, false, false, false, false, false};
        
        //Check if one or more fields is empty
        for(int i = 0; i < 6; i++){
            if(checkTextFields[i].isEmpty()){
                switch(i) {
                    case 0:
                        realNameError.setText("*Please enter your name.");
                        break;
                    case 1:
                        uNameError.setText("*Please enter a username.");
                        break;
                    case 2:
                        passError.setText("*Please enter a password.");
                        break;
                    case 3:
                        matchError.setText("*Re-enter password.");
                        break;
                    case 4:
                        emailError.setText("*Please enter a valid email address.");
                        break;
                    case 5:
                        numberError.setText("*Please enter a valid contact number.");
                        break;
                    default:                     
                        break;
                }       
            }
            //This would check each textfield that has at least 1 character inside it
            else if(!checkTextFields[i].isEmpty()){
                switch(i) {
                    case 0:
                        //Check database if there's already a user with a similar real name
                        if(storeRealNameText.equals(realNameCheck)){
                            realNameError.setText("This person already has an account.");
                        }
                        else{
                            checkFieldsFilledCorrectly[i] = true;
                        }
                        break;
                    case 1:
                        //Check database if there's already a user with a similar username
                        if(storeUserNameText.equals(userNameCheck)){
                            uNameError.setText("This username is taken.");
                        }
                        else{
                            checkFieldsFilledCorrectly[i] = true;
                        }   
                        break;
                    case 2:
                        //Check if the password is > 8 letters and has numbers
                        if(passWord.getText().length() < 8){
                            passError.setText("*The password needs at least 8 characters.");
                        }
                        else{
                            checkFieldsFilledCorrectly[i] = true;
                        }
                        break;
                    case 3:
                        //Check if the passwords match
                        if(!passWord.getText().equals(confirmPass.getText())){
                            matchError.setText("*Passwords do not match.");                              
                        }
                        else{
                            checkFieldsFilledCorrectly[i] = true;
                        }
                        break;
                    case 4:
                        //Check if the email is valid
                        if(!emailInput.getText().endsWith("gmail.com")){
                            emailError.setText("*Please enter a valid email address. (Gmail)");
                        }
                        else{
                            checkFieldsFilledCorrectly[i] = true;
                        }
                        //Check database if there's already a user with a similar email, or if the input is actually an email
                        break;
                    case 5:
                        //Check if the contact number is valid
                        if(contactNum.getText().length() != 11 || !contactNum.getText().startsWith("09")){
                            numberError.setText("*Please enter a valid contact number.");
                        }
                        else{
                            checkFieldsFilledCorrectly[i] = true;
                        }
                    default:                      
                        break;
                }
            }           
        }//End of For Loop        
        
        //Check if all fields were filled correctly
        //This would return true if all fields were filled correctly
        if(checkFieldsFilledCorrectly[0] == true && checkFieldsFilledCorrectly[1] == true && checkFieldsFilledCorrectly[2] == true 
                && checkFieldsFilledCorrectly[3] == true && checkFieldsFilledCorrectly[4] == true 
                && checkFieldsFilledCorrectly[5] == true){
            creationSuccess = true;
        } 
        return creationSuccess;
    }//Method end
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
