/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafxapplication11;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.media.MediaView;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Lord Geese
 */
public class FlightCancelSuccessController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @FXML Media video;
    @FXML MediaPlayer player;
    @FXML MediaView mediaplayer;
    
    @FXML private String name;
    
    @FXML
    public void saveUserName(String name){
        this.name = name;
    }
    
    @FXML
    private void checkStatus() throws Exception{
        player.setAutoPlay(true);
        
        player.setOnEndOfMedia(new Runnable(){
            @Override
            public void run() {
                try {
                    mainScreen();             
                } 
                catch(Exception e){
                    System.out.println(e);
                }
            }          
        });
    }
    
    @FXML
    private void mainScreen() throws Exception{ 
        Scene welcomeScreenScene = mediaplayer.getScene();
        Stage welcomeEnd = (Stage)welcomeScreenScene.getWindow();
        welcomeEnd.close();
        
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("MainScreen.fxml"));
        Parent mainScreen = loader.load();
        
        MainScreenController control = loader.getController();
        control.saveUserName(name);
        
        Scene mainScreenScene = new Scene(mainScreen);
        Stage mainScreenStart = new Stage();
        mainScreenStart.setMaxWidth(1220);
        mainScreenStart.setMaxHeight(850);
        mainScreenStart.setScene(mainScreenScene);
        mainScreenStart.centerOnScreen();
        mainScreenStart.setTitle("Hover");
        mainScreenStart.showAndWait();     
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        String videoSource = "file:/C:/Users/CancelComplete.mp4";
        video = new Media(videoSource);
        player = new MediaPlayer(video);  
        mediaplayer.setMediaPlayer(player);

        try {
             checkStatus();
        }
        catch(Exception error) {
             System.out.println(error);
        }     
    }    
    
}
