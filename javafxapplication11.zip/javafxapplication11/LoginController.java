/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafxapplication11;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.scene.control.*;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;

/**
 *
 * @author Lord Geese
 */
public class LoginController implements Initializable {
    
    public applicationToDatabase endUser;
    
    @FXML TextField userField;
    @FXML PasswordField passField;
    @FXML Label invalidUser, invalidPass;
    
    //Checks if the username and password fields are correctly filled out
    @FXML
    private void signIn(ActionEvent event) throws Exception{  
        //By setting this to blank, each call on the method would return different texts on the error labels
        invalidUser.setText("");
        invalidPass.setText("");
        
        endUser = new applicationToDatabase(userField.getText(), passField.getText());
        String confirmation = endUser.signIn();
        
        //Error labels display these messages if both fields are empty
        if(userField.getText().isEmpty() && passField.getText().isEmpty()){
            invalidUser.setText("*This field cannot be empty.");
            invalidPass.setText("*This field cannot be empty.");
        }
        //Error labels will do the ff. if both fields are not empty
        else if(!userField.getText().isEmpty() && !passField.getText().isEmpty()){
            switch(confirmation){
                case "Success":
                    welcomeScreen(event);
                    break;
                case "Both":
                    invalidUser.setText("*Username and password do not match");
                    invalidPass.setText("*Username and password do not match");;
                    break;
                case "NoUser":
                    invalidUser.setText("*No such username");
                    break;
                case "IncorrectPass":
                    invalidPass.setText("*Incorrect Password");
                    break;
                default:
                    break;
            }
        }
        //Error labels will display these messages if one of the fields is empty
        else if(userField.getText().isEmpty()){
            invalidUser.setText("*This field cannot be empty.");
        }
        else if(passField.getText().isEmpty()){
            invalidPass.setText("*This field cannot be empty.");
        }  
    }  
    
    //Access the welcome screen, which leads to the main screen
    @FXML
    private Stage welcomeScreen(ActionEvent event) throws Exception{
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("Welcome.fxml"));
        Parent welcomeScreen = loader.load();
        
        //Access the welcome controller's methods
        WelcomeController control = loader.getController();
        control.saveUserName(userField.getText());
        
        Scene welcomeScreenScene = new Scene(welcomeScreen);
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        
        window.setScene(welcomeScreenScene);
        window.setTitle("Welcome!");
        window.show();
        window.centerOnScreen();
        
        return window;
    } 
    
    //Access account creation screen
    @FXML
    private void createAccount(ActionEvent event) throws Exception{
        Parent createAccount = FXMLLoader.load(getClass().getResource("createAccount.fxml"));
        
        Scene createAccountScene = new Scene(createAccount);
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        
        window.setScene(createAccountScene);
        window.setTitle("Account Creation");
        window.centerOnScreen();
        window.show();
    } 
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
