/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafxapplication11;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Lord Geese
 */
public class ReservationController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @FXML Label message;
    @FXML Button returnToMain;
    @FXML private String name;
    
    @FXML
    public void saveUserName(String name){
        this.name = name;
    }
    
    //Return to the main screen
    @FXML
    private void goBack(ActionEvent event) throws Exception{
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("MainScreen.fxml"));
        Parent mainScreen = loader.load();
        
        MainScreenController control = loader.getController();
        control.saveUserName(name);
        
        Scene mainScene = new Scene(mainScreen);
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(mainScene);
        window.setTitle("Hover");
        window.show();
    }
    
    //Change the message for when the user has a reservation or not
    @FXML
    public void changeMessage(String msg){
        message.setText(msg);
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
