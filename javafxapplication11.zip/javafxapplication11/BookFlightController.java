/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafxapplication11;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Lord Geese
 */
public class BookFlightController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @FXML Button cancelBooking;
    
    @FXML private String name;
    
    @FXML
    public void saveUserName(String name){
        this.name = name;
    }
    
    
    //Goes back to the main screen
    @FXML
    private void returnToMainScreen(ActionEvent event) throws Exception{  
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("MainScreen.fxml"));
        Parent mainScreen = loader.load();
        
        MainScreenController control = loader.getController();
        control.saveUserName(name);
        
        Scene mainScreenScene = new Scene(mainScreen);
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        
        window.setScene(mainScreenScene);
        window.setTitle("Hover");
        window.centerOnScreen();
        window.show();        
    }
    
    //Accesses the booking confirmation scene
    @FXML
    private void proceedToConfirmation(ActionEvent event) throws Exception{
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("BookingConfirmation.fxml"));
        Parent confirmation = loader.load();
        
        BookingConfirmationController controller = loader.getController();  
        Button flight = (Button)event.getSource();
        
        controller.changeFlightLabel(flight.getText());
        controller.changeValues(flight.getText());
        controller.saveUserName(name);
        
        Scene confirmationScene = new Scene(confirmation);
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        
        window.setScene(confirmationScene);
        window.setTitle("Booking");
        window.centerOnScreen();
        window.show();   
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
