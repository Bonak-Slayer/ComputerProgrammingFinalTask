/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafxapplication11;

import java.sql.*;

/**
 *
 * @author Lord Geese
 */
public class flightBookingToDatabase {
    private String query;
    private String url = "jdbc:mysql://localhost:3306/allFlights";
    private String username = "flightMaster";
    private String password = "accessFlights";
    private Connection conn;
    
    private String flight, flightDuration, userName, flightTime, flightDate, flightPrice;
    private String realName;
    private int user_id, reserved;
    
    public flightBookingToDatabase(String flight, String flightDuration, String userName, String flightTime, String flightDate,
            String flightPrice){
        this.flight = flight;
        this.flightDuration = flightDuration;
        this.userName = userName;
        this.flightTime = flightTime;
        this.flightDate = flightDate;
        this.flightPrice = flightPrice;
        
        getRealName(userName);
    }
    
    public void bookFlight(){
        try{
            conn = DriverManager.getConnection(url, username, password);
            System.out.println("Checking the reservation status...");
            
            query = "SELECT has_reservation FROM user_information WHERE username = ?";
            PreparedStatement prep = conn.prepareStatement(query);
            prep.setString(1, userName);
            ResultSet rs = prep.executeQuery();
            
            while(rs.next()){
                reserved = rs.getInt(1);
            }
            
            query = "SELECT user_id FROM user_information WHERE username = ?";
            prep = conn.prepareStatement(query);
            prep.setString(1, userName);
            rs = prep.executeQuery();
            
            while(rs.next()){
                user_id = rs.getInt(1);
            }
            System.out.println(user_id);
            
            //This is used if the user doesn't have a reservation yet
            if(reserved == 0){
                System.out.println("Inserting values into the database...");
            
                query = "INSERT INTO bookedFlights(id, true_name, flight_name, flight_duration, "
                        + "time_of_flight, flight_date, amount) VALUES" +
                        "(?,?,?,?,?,?,?)";

                prep = conn.prepareStatement(query);
                prep.setInt(1, user_id);
                prep.setString(2, realName);
                prep.setString(3, flight);
                prep.setString(4, flightDuration);
                prep.setString(5, flightTime);
                prep.setString(6, flightDate);
                prep.setString(7, flightPrice);
                prep.execute();

                System.out.println("Insertion successful!");
            }
            //Otherwise, this would be used to update the values in the second database instead
            //This is used if the user rescheduled the flight
            else{
                System.out.println("Updating values...");
                
                query = "UPDATE bookedFlights SET flight_name = ?, flight_duration = ?, " +
                        "time_of_flight = ?, flight_date = ?, amount = ? WHERE true_name = ?";
                
                prep = conn.prepareStatement(query);
                prep.setString(1, flight);
                prep.setString(2, flightDuration);
                prep.setString(3, flightTime);
                prep.setString(4, flightDate);
                prep.setString(5, flightPrice);
                prep.setString(6, realName);
                prep.execute();
                
                System.out.println("Update successful!");
            }          
        }catch(Exception e){
            System.out.println(e);
        }
        finally{
           try{
               if(conn != null){
                   conn.close();
               }
           }catch(SQLException e1){
                System.out.println(e1.getMessage());
            }//catch end
        }
    }//Booking method end
    
    //This is a necessary method because we generally do not want the user to reveal their real name.
    //This means that we have to determine what is the real name of the user based from their username.
    private void getRealName(String name){
        try{
            Connection conn = DriverManager.getConnection(url, username, password);
            System.out.println("Getting the real name of the user...");
            
            query = "SELECT real_name FROM user_information WHERE username = ?";
            
            PreparedStatement prep = conn.prepareStatement(query);
            prep.setString(1, name);
            ResultSet rs = prep.executeQuery();
            
            while(rs.next()){
                realName = rs.getString(1);
            }
            
            System.out.println("Acquisition successful!");
        }catch(SQLException e){
            System.out.println(e);
        }finally{
            try{
                if(conn != null){
                    conn.close();
                }
            }catch(Exception h){
                System.out.println(h);
            }
        }
    }//Real name acquisition method end
    
    //Updates the has_reservation property in the database
    //This is used to tell the database that the user already has a reservation.
    public void reservationComplete(){
        try{
            Connection conn = DriverManager.getConnection(url, username, password);
            System.out.println("Updating user information...");
            
            query = "UPDATE user_information SET has_reservation = ? WHERE real_name = ?";
            
            PreparedStatement prep = conn.prepareStatement(query);
            prep.setInt(1, 1);
            prep.setString(2, realName);
            prep.execute();
            
            System.out.println("Update successful!");
            
        }catch(SQLException e){
            System.out.println(e);
        }finally{
            try{
                if(conn != null){
                    conn.close();
                }
            }catch(Exception h){
                System.out.println(h);
            }
        }
    }
}
