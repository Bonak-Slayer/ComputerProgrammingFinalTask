/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafxapplication11;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.media.MediaView;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Lord Geese
 */
public class MainScreenController implements Initializable {

    @FXML private Media source;
    @FXML private MediaPlayer player;
    @FXML private MediaView advertise;
    @FXML private Button signOut;
    @FXML private Button bookButton, cancelButton;
    
    @FXML private String name;
    @FXML private ReservationCheck booking;
    @FXML private UpdateBookingController message;
    
    @FXML
    public void saveUserName(String name){
        this.name = name;
    }
    
    @FXML
    private void signOut(ActionEvent event) throws Exception{
        Parent returnToLogin = FXMLLoader.load(getClass().getResource("userFinished.fxml"));
        
        Scene returnToLoginScene = new Scene(returnToLogin);
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        
        window.setScene(returnToLoginScene);
        window.setTitle("Farewell");
        window.centerOnScreen();
        window.show();
    }
    
    //Method to access the booking screen. Would render another scene if the user already has a booking
    @FXML
    private void bookFlight(ActionEvent event) throws Exception{
        booking = new ReservationCheck(name);
        
        //This will render an error screen if the user already has a booking
        if(booking.checkForReservations() == true){
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("Reservation.fxml"));
            Parent flightBooking = loader.load();

            ReservationController control = loader.getController();
            control.saveUserName(name);
            control.changeMessage("It seems that you already have a reservation...");

            Scene bookFlightScene = new Scene(flightBooking);
            Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();

            window.setScene(bookFlightScene);
            window.setTitle("Oof...");
            window.centerOnScreen();
            window.show();
        }
        //This will render the booking screen if the user doesn't have a booking
        else{
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("BookFlight.fxml"));
            Parent flightBooking = loader.load();

            BookFlightController control = loader.getController();
            control.saveUserName(name);

            Scene bookFlightScene = new Scene(flightBooking);
            Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();

            window.setScene(bookFlightScene);
            window.setTitle("Book a Flight");
            window.centerOnScreen();
            window.show();
        }     
    }//Method end
    
    @FXML
    private void cancelFlight(ActionEvent event) throws Exception{
        booking = new ReservationCheck(name);
        
        //This will render an error screen if the user already has a booking
        if(booking.checkForReservations() == true){
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("UpdateBooking.fxml"));
            Parent update = loader.load();
            
            UpdateBookingController control = loader.getController();
            String flightName = booking.getFlight("name");
            String flightDuration = booking.getFlight("duration");
            String flightDate = booking.getFlight("date");
            String flightTime = booking.getFlight("time");
            control.saveUserName(name);
            control.changeTexts("Do you want to cancel this flight?", flightName, flightDuration,
                    flightDate, flightTime, "Yes, I want to cancel this booking.");
            
            Scene updateScene = new Scene(update);
            Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();

            window.setScene(updateScene);
            window.setTitle("Confirmation");
            window.centerOnScreen();
            window.show();
        }
        else{          
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("Reservation.fxml"));
            Parent flightBooking = loader.load();
            
            //Using a controller to change the message within the error screen
            ReservationController control = loader.getController();
            control.saveUserName(name);
            control.changeMessage("It seems that you don't have a reservation...");

            Scene bookFlightScene = new Scene(flightBooking);
            Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();

            window.setScene(bookFlightScene);
            window.setTitle("Oof...");
            window.centerOnScreen();
            window.show();
        }    
    }//Method end
    
    @FXML
    private void rescheduleFlight(ActionEvent event) throws Exception{
        booking = new ReservationCheck(name);
        
        //This will render an error screen if the user already has a booking
        if(booking.checkForReservations() == true){      
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("UpdateBooking.fxml"));
            Parent cancel = loader.load();
            
            UpdateBookingController control = loader.getController();
            String flightName = booking.getFlight("name");
            String flightDuration = booking.getFlight("duration");
            String flightDate = booking.getFlight("date");
            String flightTime = booking.getFlight("time");
            control.saveUserName(name);
            control.changeTexts("Do you want to reschedule this flight?", flightName, flightDuration,
                    flightDate, flightTime, "Yes, I want to reschedule my flight.");

            Scene noReservationScene = new Scene(cancel);
            Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();

            window.setScene(noReservationScene);
            window.setTitle("Reschedule");
            window.centerOnScreen();
            window.show();      
        }
        else{
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("Reservation.fxml"));
            Parent flightBooking = loader.load();
            
            //Using a controller to change the message within the error screen
            ReservationController control = loader.getController();
            control.saveUserName(name);
            control.changeMessage("It seems that you don't have a reservation...");

            Scene bookFlightScene = new Scene(flightBooking);
            Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();

            window.setScene(bookFlightScene);
            window.setTitle("Oof...");
            window.centerOnScreen();
            window.show();
        }
    }//Method end
    
    @FXML
    public void viewDetails(ActionEvent event) throws Exception{
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("ViewDetails.fxml"));
        Parent viewDetailScreen = loader.load();
        
        ViewDetailsController control = loader.getController();
        control.saveUserName(name);
        
        Scene viewDetailsScene = new Scene(viewDetailScreen);
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        
        window.setScene(viewDetailsScene);
        window.setTitle("About Us");
        window.centerOnScreen();
        window.show();
    }//Method End
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
 
    }    
    
}
