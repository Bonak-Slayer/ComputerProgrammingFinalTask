/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafxapplication11;

import java.net.URL;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Lord Geese
 */
public class BookingConfirmationController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @FXML Label selectedFlight, estimate, price, flightSelectionError;
    @FXML DatePicker selectedDate;
    @FXML RadioButton firstOption, secondOption, thirdOption, fourthOption, fifthOption, sixthOption;
    @FXML ToggleGroup options;
    
    private flightBookingToDatabase reservation;
    private String selectedTime;
    private String date;
    private String userName;
    
    @FXML
    public void saveUserName(String name){
        this.userName = name;
    }
    
    //This method is necessary to display the client's selected flight in the header of the following scene
    @FXML
    public void changeFlightLabel(String flightName){
        selectedFlight.setText(flightName);
    }
    
    @FXML
    public void changeValues(String flightName){
        /*Change the estimated time in the booking confirmation screen depending on the
        selected destination of the client*/
        switch(flightName){
            case "Philippines to Japan":
                estimate.setText("4 hours and 14 minutes");
                price.setText("PHP 26,419.00");
                break;
            case "Philippines to Thailand":
                estimate.setText("3 hours and 28 minutes");
                price.setText("PHP 30,512.00");
                break;
            case "Philippines to Indonesia":
                estimate.setText("2 hours and 59 minutes");
                price.setText("PHP 7,550.00");
                break;
            case "Japan to Philippines":
                estimate.setText("4 hours and 14 minutes");
                price.setText("PHP 26,419.00");
                break;
            case "Japan to South Korea":
                estimate.setText("1 hour and 57 minutes");
                price.setText("PHP 4,394.00");
                break;
            case "Indonesia to South Korea":
                estimate.setText("7 hours and 3 minutes");
                price.setText("PHP 15,530.00");
                break;
            case "Indonesia to Philippines":
                estimate.setText("2 hours and 59 minutes");
                price.setText("PHP 7,550.00");
                break;
            case "South Korea to Indonesia":
                estimate.setText("7 hours and 3 minutes");
                price.setText("PHP 15,530.00");
                break;
            case "South Korea to Japan":
                estimate.setText("1 hour and 57 minutes");
                price.setText("PHP 4,394.00");
                break;
            case "Thailand to Philippines":
                estimate.setText("3 hours and 28 minutes");
                price.setText("PHP 30,512.00");
                break;             
        }
    }
    
    @FXML
    private void finishBooking(ActionEvent event) throws Exception{
        if(selectedDate.getValue() == null){
            flightSelectionError.setText("*Please specify a date.");
        }
        else{
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("BookingSuccess.fxml"));
            Parent successScreen = loader.load();  
        
            BookingSuccessController control = loader.getController();      
            control.saveUserName(userName);   
        
            Scene successScene = new Scene(successScreen);
            Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        
            //Inserting values into the DB
            processValues();
        
            //The creation of the object is necessary so that the method in the java class can be used
            //This method will insert the values into the bookedFlights database, using data from the object
            reservation = new flightBookingToDatabase(selectedFlight.getText(), estimate.getText(), userName, selectedTime, 
                    date, price.getText());
            reservation.bookFlight();
            reservation.reservationComplete();
        
            window.setScene(successScene);
            window.setTitle("Booking Successful!");
            window.centerOnScreen();
            window.show();          
        }
    }
    
    @FXML
    private void previousScreen(ActionEvent event) throws Exception{  
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("BookFlight.fxml"));
        Parent mainScreen = loader.load();
        
        BookFlightController control = loader.getController();
        control.saveUserName(userName);
        
        Scene mainScreenScene = new Scene(mainScreen);
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        
        window.setScene(mainScreenScene);
        window.setTitle("Hover");
        window.centerOnScreen();
        window.show();        
    }
    
    @FXML
    private void processValues(){  
        //This would set the value of the selected time
        //This value would then be used while inserting data into the DB
        
        //Since a ToggleGroup is used, we have to get the "selected time" from te radio button selected
        if(options.getSelectedToggle().equals(firstOption)){
            selectedTime = firstOption.getText();
        }
        else if(options.getSelectedToggle().equals(secondOption)){
            selectedTime = secondOption.getText();
        }
        else if(options.getSelectedToggle().equals(thirdOption)){
            selectedTime = thirdOption.getText();
        }
        else if(options.getSelectedToggle().equals(fourthOption)){
            selectedTime = fourthOption.getText();
        }
        else if(options.getSelectedToggle().equals(fifthOption)){
            selectedTime = fifthOption.getText();
        }
        else if(options.getSelectedToggle().equals(sixthOption)){
            selectedTime = sixthOption.getText();
        }
        
        date = selectedDate.getValue().format(DateTimeFormatter.ofPattern("MM-dd-yyyy"));
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        //Groups all individual radio buttons
        options = new ToggleGroup();
        firstOption.setToggleGroup(options);
        secondOption.setToggleGroup(options);
        thirdOption.setToggleGroup(options);
        fourthOption.setToggleGroup(options);
        fifthOption.setToggleGroup(options);
        sixthOption.setToggleGroup(options);
        
        options.selectToggle(firstOption);
        
    }    
    
}
